SELECT * ,
(1-pre_invoice_discount_pct)*gross_price_total as net_invoice_sales,
(PID.discounts_pct+PID.other_deductions_pct) as post_invoice_discount_pct
FROM gdb0041.sales_preinv_discount as SPD
join fact_post_invoice_deductions AS PID
on PID.DATE=SPD.DATE AND
PID.CUSTOMER_CODE=SPD.CUSTOMER_CODE AND
PID.PRODUCT_CODE=PID.product_code