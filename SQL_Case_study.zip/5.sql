select * from movies;
select * from financials;

select movies.movie_id, movies.title, financials.budget, financials.revenue, financials.currency, financials.unit
from movies
left join financials
on movies.movie_id=financials.movie_id

union
select movies.movie_id, movies.title, financials.budget, financials.revenue, financials.currency, financials.unit
from movies
right join financials
on movies.movie_id=financials.movie_id;

select * from movies;
select * from languages;


select m.language_id, m.title, l.name
from movies m
left join languages l
on m.language_id=l.language_id
union
select m.language_id, m.title, l.name
from movies m
right join languages l
on m.language_id=l.language_id;


select m.title, m.language_id, l.name
from movies m 
left join languages l
on m.language_id=l.language_id
where l.name='Telugu';

select l.name, count(m.title), m.language_id
from movies m 
left join languages l
on m.language_id=l.language_id
group by l.name, m.language_id