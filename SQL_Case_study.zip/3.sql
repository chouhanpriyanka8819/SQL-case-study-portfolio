select * 
from parks_and_recreation.employee_demographics
where gender NOT LIKE '%Female%'
;
SELECT gender, avg(age), max(age)
from parks_and_recreation.employee_demographics
group by 1;

select *
from parks_and_recreation.employee_demographics
order by gender, age;

select gender, avg(age)
from parks_and_recreation.employee_demographics
group by gender
having avg(age) > 40;

select occupation, avg(salary)
from parks_and_recreation.employee_salary
where occupation like '%manager%'
group by occupation;

select *
from parks_and_recreation.employee_demographics
limit 3;

SELECT *
FROM SQLTutorial.dbo.employee_demographics

