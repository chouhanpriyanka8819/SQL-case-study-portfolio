select * from sales;
select SaleDate, Amount, Customers
from sales;
select SaleDate, amount, Boxes, amount/Boxes as 'amount per box' from sales;
select *
 from sales 
 where Amount>10000
 order by amount;
 select * from sales
 where GeoID='G1'
 order by PID, Amount DESC;
 
 SELECT * FROM SALES
 WHERE amount>10000 and saledate >= '2022-01-01';
 
 select amount, saledate from sales
 where Amount>10000 and year(saledate)=2022;
 
 select * from sales 
 where Boxes between 0 and 50
 >0 and Boxes<= 50;
 
 
 select * from people;
 
 select * from people;
 
 select * from people where Team = 'delish' or 'yummies'
 
 select * from people
 where team in ('delish', 'jucies');
 select SaleDate, Amount,
	case when amount <1000 then 'Under 1k'
		when amount<5000 then 'Under 5k'
        when amount<10000 then 'Under 10k'
        else '10k or more'
        end as 'Amount category'
  from sales;
 
 select * from sales;
 select * from people;
  
 select  S.SPID, S.Amount, S.SaleDate, P.Salesperson
 from sales as S
 JOIN people AS P ON P.SPID=S.SPID;
 
 SELECT * FROM products;
  select * from sales;
   select * from people;
  
SELECT S.SaleDate, S.Amount, S.PID, P.Product
FROM SALES AS S
JOIN products AS P ON P.PID=S.PID;
  
 SELECT S.SPID, S.SALESDATE, S.AMOUNT, P.SALESPERSON
 FROM SALES AS S
JOIN PEOPLE AS P ON P.SPID=S.SPID
LEFT JOIN products AS PR ON PR.PID=S.PID;

SELECT geoID, sum(AMOUNT) 
FROM SALES
group by GEOID;

select * from actors where actor_id = any (
select actor_id from movie_actor where movie_id in (101,110,121));

##movie rating > any of the marvel movie
select * from movies where studio not like 'Marvel studios' and imdb_rating>'8.4'
order by imdb_rating desc;

##select actor id actor name and total nos of movies they acted in 
select * from actors;
select * from movie_actor;
select * from movies;

select 
	actor_id, 
    name,
    (select count(*) from movie_actor
    where actor_id=actors.actor_id) as movies_count
    from actors ;
    
    select * from movies where release_year in(
    (select min(release_year) from movies), (select max(release_year) from movies));
    
    ##select all rows from movies whose imdb rating is higher than the average rating
    select * from movies where imdb_rating > (
    select avg(imdb_rating) from movies) ;
    
explain analyze
select a.actor_id, a.name, count(*) as movies_count from movie_actor ma
join actors a
on a.actor_id=ma.actor_id
group by a.actor_id
order by movies_count desc;
  
##get all actors between age 70 and 85
select * from movie_actor;
select actor_name, age from (
select name as actor_name, (year(curdate())-birth_year) as age from actors) as actor_age where age >70 and age<85;
  
 with actor_age as(select name as actor_name, (year(curdate())-birth_year) as age from actors) 
  select actor_name, age from actor_age where age>;

WITH actors_age AS (  select name as actor_name, (year(curdate())-birth_year) as age from actors)
select actor_name, age FROM actors_age where age >70 and age<85;

##movies that produce 500 % profit and their rating was less than avg rating for all movies;
select * from movies;
select * from financials;

WITH x AS(
select 
	*, 	
    (revenue-budget)*100/budget as pft_percent 
    from financials
    where (revenue-budget)*100/budget>=500),
 y AS(
select * from movies
where	imdb_rating<(select avg(imdb_rating) from movies)
)

select x.pft_percent, x.movie_id,
	y.title, y.imdb_rating
 from x
join y
on x.movie_id=y.movie_id


##using sub query
select M.pft_percent, M.movie_id,
	F.title, F.imdb_rating
from (select 
	*, 	
    (revenue-budget)*100/budget as pft_percent 
    from financials
    where (revenue-budget)*100/budget>=500) M
join (select * from movies
where	imdb_rating<(select avg(imdb_rating) from movies)
) F 
ON M.movie_id=F.movie_id;

##all hollywood movies after 2000
select * from movies where release_year>2000
##made pft equal to and more than 500 milliom