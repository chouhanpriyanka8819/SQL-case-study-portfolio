SELECT * FROM random_tables.expenses
order by category, date;

select *, sum(amount) over(partition by category order by date) as am
from random_tables.expenses
order by category, date