SELECT * 
FROM gdb0041.dim_product;

with cte1 as
(SELECT p.division, p.product, sum(sold_quantity) AS total_qty
FROM fact_sales_monthly s
JOIN dim_product p
ON s.product_code=p.product_code 
where fiscal_year=2021
group by p.division, p.product),
cte2 as(
select *, row_number() OVER(partition by division order by total_qty desc) as rn,
rank() over(partition by division order by total_qty desc) as rnk,
dense_rank() over(partition by division order by total_qty desc) as dnk
from cte1)
select * from cte2
where dnk<=3;
