SELECT title, industry FROM moviesdb.movies;
select count(*) from movies where industry= 'bollywood';
select distinct (industry) from movies where industry= 'hollywood';

select title, release_year from movies	where studio= 'Marvel Studios';
select title from movies where title like '%Avenger%';
select title, release_year from movies where title='The Godfather';
select distinct(studio) from movies where industry ='Bollywood';

select * from movies where imdb_rating>=9;
select * from movies where release_year in (2018,2019,2022);
select * from movies where studio in ("marvel studios", "ZEE Studios");
select * from movies where imdb_rating is not null;
      
select * from movies where imdb_rating between 5 and 9;
select * from movies where industry="bollywood"	
order by imdb_rating desc limit 5;
select * from movies where industry="hollywood"
order by imdb_rating desc limit 5 offset 1;

select * from movies
order by release_year desc;
select * from movies where release_year=2022;
select * from movies where release_year>2020;
select * from movies where release_year>2020 and imdb_rating>8;
select * from movies where studio="Marvel studios" or studio="Hombale Films";
select * from movies where title like '%Thor%' order by release_year;
select * from movies where studio <>"Marvel studios";

select round(avg(imdb_rating),2) from movies where studio="Marvel Studios";
select  min(imdb_rating) as min_rating,
max(imdb_rating) as max_rating,
round(avg(imdb_rating),2) as avg_rating from movies where studio="marvel studios";
select count(*) from movies where industry="bollywood";
select industry, count(*) title from movies -- where industry in ('hollywood','bollywood')
group by industry;
select studio, count(*), round(avg(imdb_rating),2) as avg_rating from movies where studio !=""
group by studio
order by avg_rating desc;

select release_year, count(*) from movies where release_year between 2015 and 2022
group by release_year;
select max(release_year), min(release_year) from movies;
select release_year, count(release_year) as total_movies from movies
group by release_year
order by release_year desc;

select release_year, count(*) as total_movies from movies
group by release_year
having total_movies>2;

select *, year(curdate())-birth_year as Age from actors;
select *, 
CASE
WHEN UNIT='BILLIONS' THEN REVENUE*1000
WHEN UNIT='THOUSANDS'THEN REVENUE/1000
WHEN unit='MILLIONS' THEN revenue
END as revenue_MILN
from financials;
SELECT * FROM FINANCIALS;
SELECT *,
((revenue-budget)/budget)*100 AS PROFIT FROM financials;

SELECT COUNT(distinct IMDB_RATING) FROM MOVIES;
SELECT stddev(IMDB_RATING) FROM movies;

SELECT * FROM CUSTOMERS WHERE CUSTOMERS_ID;
SELECT * FROM PLAYERS order by DESC LIMIT 3 OFFSET 1;
SELECT * FROM MOVIES WHERE title like "THE%" AND IMdb_rating>5 and imdb_rating<=6;

select * from moviesdb.movies
cross join moviesdb.financials