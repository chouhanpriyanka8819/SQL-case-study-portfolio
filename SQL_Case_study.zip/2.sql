-- Assumed Database Tables  
  -  fct_order: order_id | order_timestamp | user_id | vertical | location_id
dim_location: location_id | area | city | country
dim_date: date | month | year

Multi Vertical users
P1: Count of Active Users who have placed at least 1 order in the past 90 days from each vertical per Country
Expected Output: Country, MVA_users_count

WITH recent_orders AS (
SELECT user_id, country, vertical
from fct_order
JOIN dim_location 1 ON location_id= 1.location_id
where
order_timestamp >= CURRENT_DATE - INTERVAL '90 days'
GROUP BY user_id, country, vertical),
multi_vertical_users AS (
SELECT user_id, country, COUNT(DISTINCT vertical) AS vertical_count
FROM recent_orders
GROUP BY user_id, country
HAVING COUNT (Distinct vertical)>1)
SELECT country, COUNT (DISTINCT user_id) AS MVA_users_count
FROM multi_vertical_users
GROUP BY country

WITH date_series AS (
SELECT date 
from dim_date
where date >= '2024-01-01' ),
recent orders AS (
SELECT user_id, country, vertical, 
MVA_users_count
from date_series 
LEFT Join multi_vertical_users mv 
ON mv.order