
##all hollywood movies after 2000
select * from movies  
where industry='Hollywood' 
and release_year>2000;

##made pft equal to and more than 500 milliom
select *, (revenue-budget) as pft from financials where (revenue-budget)>=500;

##using CTE
WITH X AS(select * from movies  
where industry='Hollywood' 
and release_year>2000
),
	Y AS (select *, (revenue-budget) as pft from financials where (revenue-budget)>=500
    )
select X.title, X.industry,  
	Y.pft
	from X
join Y
on x.movie_id=y.movie_id		

with deptt_avg as (select deptt, avg(salary) as avg_sal
from salaries
grp by deptt)

select *
from salaries s
join deptt_avg
on s.deptt=deptt_avg.deptt
where s.salary > deptt_avg.avg_salmovies