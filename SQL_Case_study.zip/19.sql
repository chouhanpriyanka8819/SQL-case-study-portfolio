create table fact_act_es
(
SELECT fm.date as date,
fm.fiscal_year as fiscal_year,
fm.product_code as product_code,
fm.customer_code as customer_code,
sm.sold_quantity as sold_quantity,
fm.forecast_quantity as forecast_quantity
FROM gdb0041.fact_forecast_monthly AS FM
left JOIN fact_sales_monthly AS SM
using(date,product_code,customer_code)
union
select sm.date as date,
sm.fiscal_year as fiscal_year,
sm.product_code as product_code,
sm.customer_code as customer_code,
sm.sold_quantity as sold_quantity,
fm.forecast_quantity as forecast_quantity
from fact_sales_monthly as sm
right join gdb0041.fact_forecast_monthly AS FM
using(date,product_code,customer_code)
);