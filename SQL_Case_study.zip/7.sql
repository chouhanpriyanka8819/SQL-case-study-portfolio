select * from movies where imdb_rating= (select max(imdb_rating) from movies);
----- movie with min & max imdb
select * from movies where imdb_rating in ((select min(imdb_rating) from movies) , (select max(imdb_rating) from movies));

# SELECT ALL ACTORS WHOSE AGE >70 AND < 85
select * from
(SELECT name , year(curdate())- birth_year as yrs 
FROM actors) as actor_age
where yrs>70 and yrs<85;

##select actors who acted in any of movies (101 110 121)
select * from movie_actor;
select * from movies;
select * from actors;

select * from
(select m.movie_id, m.title, ma.actor_id, a.name
from movies m
left join movie_actor ma
on m.movie_id=ma.movie_id
left join actors a 
on ma.actor_id=a.actor_id) as main
where main.movie_id in (101,110,121);

select * from actors where actor_id= any (
select actor_id from movie_actor where movie_id in (101,110,121))
