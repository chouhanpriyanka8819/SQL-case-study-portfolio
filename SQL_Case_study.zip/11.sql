SELECT FSM.DATE , SUM(ROUND(FGP.gross_price*FSM.sold_quantity)) AS GROSS_PRICE_TOTAL
FROM gdb0041.fact_sales_monthly AS FSM
JOIN gdb0041.fact_gross_price AS FGP
ON FGP.product_code=FSM.product_code AND
FGP.fiscal_year=GET_FISCAL_YEAR(FSM.DATE)
WHERE customer_code=90002002
GROUP BY FSM.DATE
ORDER BY FSM.DATE ASC;

SELECT FGP.fiscal_year , SUM(FGP.gross_price*FSM.sold_quantity) AS GROSS_PRICE_TOTAL
FROM gdb0041.fact_sales_monthly AS FSM 
JOIN gdb0041.fact_gross_price AS FGP
ON FGP.product_code=FSM.product_code AND
FGP.fiscal_year=GET_FISCAL_YEAR(FSM.DATE)
WHERE customer_code=90002002
GROUP BY FGP.fiscal_year
ORDER BY FGP.fiscal_year ASC;

SELECT * FROM fact_sales_monthly