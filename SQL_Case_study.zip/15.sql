SELECT * FROM random_tables.expenses
ORDER BY category;

## show top 2 exp in each category

with cte1 as
(select 
*,
row_number() over(partition by category order by amount desc) as rn,
rank() over(partition by category order by amount desc) as rnk,
dense_rank() over(partition by category order by amount desc) as dnk
from expenses
order by category)
select * 
from cte1
where rn<3