SELECT FSM.date, FSM.sold_quantity, DP.product, DP.variant, FSM.product_code, FGP.fiscal_year, FGP.gross_price, round (FGP.gross_price*FSM.sold_quantity,2) as gross_price_total
 FROM gdb0041.fact_sales_monthly FSM
JOIN gdb0041.dim_product AS DP
ON FSM.product_code= DP.product_code
JOIN gdb0041.fact_gross_price AS FGP
ON FGP.product_code=FSM.product_code and FGP.fiscal_year=get_fiscal_year(FSM.date)
-- WHERE customer_code=90002002 
-- AND GET_FISCAL_YEAR(DATE)=2021 
ORDER BY DATE;

SELECT FSM.product_code, FSM.date, FSM.sold_quantity, DP.product, DP.variant, FSM.customer_code, FGP.gross_price, FGP.fiscal_year, FMC.manufacturing_cost, FMC.cost_year 
FROM gdb0041.fact_sales_monthly AS FSM
JOIN gdb0041.dim_product AS DP
JOIN gdb0041.fact_gross_price AS FGP
JOIN gdb0041.fact_manufacturing_cost AS FMC
ON FSM.product_code= DP.product_code AND FGP.product_code=FSM.product_code AND FMC.product_code=FSM.product_code
WHERE FSM.customer_code=90002002 AND YEAR(date_add(DATE, INTERVAL 4 MONTH))=2021
ORDER BY date DESC;

SELECT SUM(FSM.SOLD_QUANTITY) AS TOTAL_QTY
FROM fact_sales_monthly AS FSM
JOIN dim_customer AS DC
ON FSM.customer_code=DC.customer_code
WHERE GET_FISCAL_YEAR(FSM.DATE)=2021 AND  DC.MARKET="India"
GROUP BY DC.MARKET;GET_MARKET_BADGE;

SELECT FSM.product_code, FSM.date, FSM.sold_quantity, DP.product, DP.variant, FSM.customer_code, FGP.gross_price, FGP.fiscal_year, FMC.manufacturing_cost, FMC.cost_year 
FROM gdb0041.fact_sales_monthly AS FSM
JOIN gdb0041.dim_product AS DP
ON FSM.product_code= DP.product_code
JOIN gdb0041.fact_gross_price AS FGP
ON FGP.FISCAL_YEAR=GET_FISCAL_
JOIN gdb0041.fact_manufacturing_cost AS FMC
 FGP.product_code=FSM.product_code AND FMC.product_code=FSM.product_code
WHERE FSM.customer_code=90002002 AND YEAR(date_add(DATE, INTERVAL 4 MONTH))=2021
ORDER BY date DESC;

select * from fact_sales_monthly