SELECT MARKET, ROUND(sum(net_sales)/1000000,2) AS NET_SALES_MLN
FROM gdb0041.net_sales
WHERE FISCAL_YEAR=2021
GROUP BY MARKET
ORDER BY net_sales_MLN
LIMIT 5;

SELECT c.customer, ROUND(sum(net_sales)/1000000,2) AS NET_SALES_MLN
FROM gdb0041.net_sales n
join dim_customer c
on c.customer_code=n.customer_code
WHERE FISCAL_YEAR=2021
GROUP BY c.customer
ORDER BY net_sales_MLN
LIMIT 5;

SELECT s.product, ROUND(sum(net_sales)/1000000,2) AS NET_SALES_MLN
FROM net_sales s
JOIN dim_product p
ON s.product_code=p.product_code 
where s.fiscal_year=2019
group by s.product
order by NET_SALES_MLN
limit 5;
##percentage sales for global net sales
with cte1 as (
SELECT c.customer, ROUND(sum(net_sales)/1000000,2) AS NET_SALES_MLN
FROM gdb0041.net_sales n
join dim_customer c
on c.customer_code=n.customer_code
WHERE n.fiscal_year=2021 -- and n.market=in_market
GROUP BY c.customer)
select *, sum(net_sales_mln) over(partition by customer) from cte1
ORDER BY net_sales_MLN desc;

with cte1 as (
SELECT c.customer, c.region, ROUND(sum(net_sales)/1000000,2) AS NET_SALES_MLN
FROM gdb0041.net_sales n
join dim_customer c
on c.customer_code=n.customer_code
WHERE n.fiscal_year=2021 -- and n.market=in_market
GROUP BY c.customer, c.region)
select *, net_sales_mln*100/sum(net_sales_mln) over(partition by region) as pct_share_region from cte1
ORDER BY region, net_sales_MLN desc;

