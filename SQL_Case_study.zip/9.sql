SELECT * FROM gdb0041.dim_customer;

-- MONTH
-- PRODUCT NAME
-- VARIANT
-- SOLD QTY
-- GROSS PRICE PER ITEM
-- GROSS PRICE TOTAL
-- CUST CODE 90002002
SELECT * FROM gdb0041.dim_customer WHERE CUSTOMER LIKE 'CROMA';

##top market
##top product
##top customer

with cte1 as(
SELECT FSM.date, FSM.sold_quantity, DP.product,FSM.customer_code, FSM.product_code, FGP.fiscal_year, FGP.gross_price, 
round (FGP.gross_price*FSM.sold_quantity,2) as gross_price_total,
PID.pre_invoice_discount_pct
-- ((round (FGP.gross_price*FSM.sold_quantity,2))-PID.pre_invoice_discount_pct) as net_invoice_sales,
-- (((round (FGP.gross_price*FSM.sold_quantity,2))-PID.pre_invoice_discount_pct)-(PIDS.discounts_pct+ PIDS.other_deductions_pct)) as net_saless
 FROM gdb0041.fact_sales_monthly FSM
JOIN gdb0041.dim_product AS DP
ON FSM.product_code= DP.product_code
JOIN gdb0041.fact_gross_price AS FGP
ON FGP.product_code=FSM.product_code and FGP.fiscal_year=FSM.fiscal_year
JOIN fact_pre_invoice_deductions AS PID 
ON PID.customer_code=FSM.customer_code and PID.fiscal_year=FSM.fiscal_year
WHERE FSM.fiscal_year=2021)
select *, (gross_price_total- gross_price_total*pre_invoice_discount_pct) as net_invoice_sales
from cte1
-- limit 1000000;
-- join fact_post_invoice_deductions as PIDS on PIDS.customer_code=FSM.customer_code

